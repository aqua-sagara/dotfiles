D2Coding Font
======================

:Font creator: Naver (company)
:Source: https://github.com/naver/d2codingfont

D2Coding is a monospace font developed by a Korean IT Company called Naver. Font
is good for displaying both Korean characters and latin characters, as sometimes
these two languages could share some similar strokes.
Since verion 1.3, D2Coding font is officially supported by the font creator, with symbols for Powerline.
Download the font from https://github.com/naver/d2codingfont/!
